const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const cors = require('cors');
const { connectDB } = require('./config/database');

// Inicialização do app
const app = express();
const PORT = process.env.PORT || 3000;

// Conectar ao banco de dados
connectDB().then(connected => {
  if (connected) {
    console.log('Banco de dados conectado');
  } else {
    console.log('Aplicação funcionando sem persistência de dados');
  }
});

// Configuração de middlewares
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'cannabis-app-secret',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Em produção, definir como true se usar HTTPS
}));

// Configuração do EJS como template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Importação das rotas
const indexRoutes = require('./routes/index');
const juridicoRoutes = require('./routes/juridico');

// Uso das rotas
app.use('/', indexRoutes);
app.use('/juridico', juridicoRoutes);

// Tratamento de erro 404
app.use((req, res) => {
  res.status(404).render('404', { title: 'Página não encontrada' });
});

// Inicialização do servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});

module.exports = app;
