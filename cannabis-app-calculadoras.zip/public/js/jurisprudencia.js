// Script específico para a página de jurisprudência

document.addEventListener('DOMContentLoaded', function() {
    initializeJurisprudenciaPage();
});

function initializeJurisprudenciaPage() {
    const filterForm = document.getElementById('jurisprudenciaFilter');
    const resultsContainer = document.getElementById('jurisprudenciaResults');
    
    if (filterForm && resultsContainer) {
        // Manipular envio do formulário de filtro
        filterForm.addEventListener('submit', function(event) {
            event.preventDefault();
            
            // Coletar dados do formulário
            const formData = new FormData(filterForm);
            const queryParams = new URLSearchParams();
            
            for (const [key, value] of formData.entries()) {
                if (value) {
                    queryParams.append(key, value);
                }
            }
            
            // Exibir indicador de carregamento
            resultsContainer.innerHTML = '<div class="loading">Carregando resultados...</div>';
            
            // Fazer requisição AJAX para o servidor
            fetch(`/juridico/jurisprudencia/filtro?${queryParams.toString()}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.results.length > 0) {
                        displayResults(data.results);
                    } else {
                        resultsContainer.innerHTML = '<p class="empty-results">Nenhum resultado encontrado para os filtros selecionados.</p>';
                    }
                })
                .catch(error => {
                    console.error('Erro ao buscar jurisprudência:', error);
                    resultsContainer.innerHTML = '<p class="error-message">Ocorreu um erro ao buscar os resultados. Por favor, tente novamente.</p>';
                });
        });
        
        // Limpar resultados ao resetar o formulário
        filterForm.addEventListener('reset', function() {
            resultsContainer.innerHTML = '<p class="empty-results">Utilize os filtros acima para buscar decisões judiciais.</p>';
        });
    }
}

function displayResults(results) {
    const resultsContainer = document.getElementById('jurisprudenciaResults');
    
    if (resultsContainer) {
        let html = '<div class="jurisprudencia-list">';
        
        results.forEach(item => {
            // Formatar resultado para exibição
            let resultadoTexto = 'Não informado';
            let resultadoClasse = '';
            
            if (item.resultado === 'deferido') {
                resultadoTexto = 'DEFERIDO';
                resultadoClasse = 'deferido';
            } else if (item.resultado === 'indeferido') {
                resultadoTexto = 'INDEFERIDO';
                resultadoClasse = 'indeferido';
            } else if (item.resultado === 'parcial') {
                resultadoTexto = 'PARCIALMENTE DEFERIDO';
                resultadoClasse = 'parcial';
            }
            
            html += `
                <div class="jurisprudencia-item">
                    <h3>${item.numeroProcesso}</h3>
                    <div class="jurisprudencia-meta">
                        <span class="tribunal">${item.tribunal} - ${item.estado}</span>
                        <span class="data">${formatDate(item.dataDecisao)}</span>
                        <span class="resultado ${resultadoClasse}">${resultadoTexto}</span>
                    </div>
                    <div class="jurisprudencia-content">
                        <p class="ementa"><strong>Ementa:</strong> ${item.ementa}</p>
                        <div class="jurisprudencia-details">
                            <p><strong>Desembargador:</strong> ${item.desembargador || 'Não informado'}</p>
                            <p><strong>Quantidade de Plantas:</strong> ${item.quantidadePlantas || 'Não informado'}</p>
                            <p><strong>Tipo de Uso:</strong> ${item.tipoUso || 'Não informado'}</p>
                        </div>
                    </div>
                    <a href="/juridico/jurisprudencia/${item.id}" class="btn btn-outline">Ver Detalhes</a>
                </div>
            `;
        });
        
        html += '</div>';
        resultsContainer.innerHTML = html;
    }
}

function formatDate(dateString) {
    if (!dateString) return 'Data não informada';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}
