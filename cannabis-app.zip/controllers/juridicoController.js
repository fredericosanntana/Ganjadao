// Controlador para o módulo jurídico
const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// Gerador de Habeas Corpus
exports.getHabeasCorpusForm = (req, res) => {
  res.render('juridico/habeas-corpus-form', { 
    title: 'Gerador de Habeas Corpus Preventivo',
    fundamentos: [
      { id: 'resp2121548', nome: 'REsp 2.121.548' },
      { id: 're635659', nome: 'RE 635659' },
      { id: 'adpf187', nome: 'ADPF 187' }
    ]
  });
};

exports.generateHabeasCorpus = async (req, res) => {
  try {
    // Obter dados do formulário
    const habeasCorpusData = {
      nome: req.body.nome,
      cpf: req.body.cpf,
      endereco: req.body.endereco,
      email: req.body.email,
      telefone: req.body.telefone,
      quantidadePlantas: req.body.quantidadePlantas,
      finalidadeUso: req.body.finalidadeUso,
      fundamentosJuridicos: Array.isArray(req.body.fundamentosJuridicos) 
        ? req.body.fundamentosJuridicos 
        : [req.body.fundamentosJuridicos],
      motivacao: req.body.motivacao
    };
    
    // Importar gerador de PDF
    const pdfGenerator = require('../utils/pdfGenerator');
    
    // Gerar PDF
    const pdfResult = await pdfGenerator.generateHabeasCorpusPDF(habeasCorpusData);
    
    // Salvar no banco de dados (se estiver conectado)
    // Implementação futura
    
    // Renderizar página de sucesso
    res.render('juridico/habeas-corpus-success', { 
      title: 'Habeas Corpus Gerado',
      message: 'Seu Habeas Corpus foi gerado com sucesso!',
      pdfPath: pdfResult.publicPath,
      fileName: pdfResult.fileName
    });
  } catch (error) {
    console.error('Erro ao gerar Habeas Corpus:', error);
    res.render('juridico/habeas-corpus-form', { 
      title: 'Gerador de Habeas Corpus Preventivo',
      fundamentos: [
        { id: 'resp2121548', nome: 'REsp 2.121.548' },
        { id: 're635659', nome: 'RE 635659' },
        { id: 'adpf187', nome: 'ADPF 187' }
      ],
      error: 'Ocorreu um erro ao gerar o Habeas Corpus. Por favor, tente novamente.'
    });
  }
};

// Central de Documentos
exports.getDocumentos = (req, res) => {
  // Importar utilitário de templates de documentos
  const documentTemplates = require('../utils/documentTemplates');
  
  // Obter lista de templates disponíveis
  const templates = documentTemplates.getAvailableTemplates();
  
  res.render('juridico/documentos', { 
    title: 'Central de Documentos',
    documentos: templates
  });
};

exports.getDocumentoTemplate = (req, res) => {
  const tipo = req.params.tipo;
  
  // Importar utilitário de templates de documentos
  const documentTemplates = require('../utils/documentTemplates');
  
  // Obter informações do template
  const templateInfo = documentTemplates.getTemplateInfo(tipo);
  
  if (!templateInfo) {
    return res.status(404).render('404', { 
      title: 'Documento não encontrado',
      message: 'O modelo de documento solicitado não foi encontrado.'
    });
  }
  
  res.render('juridico/documento-template', { 
    title: `Modelo de ${templateInfo.nome}`,
    template: templateInfo
  });
};

exports.generateDocumento = async (req, res) => {
  try {
    const tipo = req.params.tipo;
    
    // Importar utilitário de templates de documentos
    const documentTemplates = require('../utils/documentTemplates');
    
    // Verificar se o template existe
    const templateInfo = documentTemplates.getTemplateInfo(tipo);
    if (!templateInfo) {
      return res.status(404).render('404', { 
        title: 'Documento não encontrado',
        message: 'O modelo de documento solicitado não foi encontrado.'
      });
    }
    
    // Gerar PDF do documento
    const pdfResult = await documentTemplates.generateDocumentPDF(tipo, req.body);
    
    // Renderizar página de sucesso
    res.render('juridico/documento-success', { 
      title: 'Documento Gerado',
      message: `Seu ${templateInfo.nome} foi gerado com sucesso!`,
      pdfPath: pdfResult.publicPath,
      fileName: pdfResult.fileName,
      documentoNome: templateInfo.nome
    });
  } catch (error) {
    console.error('Erro ao gerar documento:', error);
    res.status(500).render('juridico/documentos', { 
      title: 'Central de Documentos',
      documentos: require('../utils/documentTemplates').getAvailableTemplates(),
      error: 'Ocorreu um erro ao gerar o documento. Por favor, tente novamente.'
    });
  }
};

exports.uploadDocumento = (req, res) => {
  // O middleware de upload já foi aplicado na rota
  // Verificar se o arquivo foi enviado
  if (!req.file) {
    return res.status(400).json({ 
      success: false, 
      message: 'Nenhum arquivo foi enviado.' 
    });
  }
  
  // Importar utilitário de upload
  const uploadHandler = require('../utils/uploadHandler');
  
  // Obter informações do arquivo
  const fileInfo = uploadHandler.getFileInfo(req.file);
  
  // Em uma implementação completa, aqui seria feito o armazenamento no banco de dados
  
  // Retornar sucesso com informações do arquivo
  res.json({ 
    success: true, 
    message: 'Documento enviado com sucesso',
    file: fileInfo
  });
};

exports.getQRCode = async (req, res) => {
  try {
    const id = req.params.id || req.query.id;
    
    if (!id) {
      return res.status(400).render('juridico/qrcode', { 
        title: 'QR Code',
        error: 'É necessário fornecer um ID de processo ou documento.'
      });
    }
    
    // Importar biblioteca QRCode e módulos necessários
    const QRCode = require('qrcode');
    const fs = require('fs');
    const path = require('path');
    
    // Criar diretório para armazenar os QR Codes se não existir
    const qrDir = path.join(__dirname, '../public/qrcodes');
    if (!fs.existsSync(qrDir)) {
      fs.mkdirSync(qrDir, { recursive: true });
    }
    
    // Definir nome do arquivo
    const timestamp = Date.now();
    const filename = `qrcode_${id}_${timestamp}.png`;
    const filePath = path.join(qrDir, filename);
    
    // Gerar QR Code
    const qrData = `PROCESSO: ${id}\nData de geração: ${new Date().toLocaleDateString('pt-BR')}`;
    await QRCode.toFile(filePath, qrData, {
      errorCorrectionLevel: 'H',
      margin: 1,
      scale: 8
    });
    
    // Renderizar página com QR Code
    res.render('juridico/qrcode', { 
      title: 'QR Code',
      id: id,
      qrCodePath: `/qrcodes/${filename}`
    });
  } catch (error) {
    console.error('Erro ao gerar QR Code:', error);
    res.status(500).render('juridico/qrcode', { 
      title: 'QR Code',
      error: 'Ocorreu um erro ao gerar o QR Code. Por favor, tente novamente.'
    });
  }
};

// Base de Jurisprudência
exports.getJurisprudencia = (req, res) => {
  // Importar utilitário de jurisprudência
  const jurisprudenciaData = require('../utils/jurisprudenciaData');
  
  // Obter estatísticas
  const estatisticas = jurisprudenciaData.getEstatisticas();
  
  res.render('juridico/jurisprudencia', { 
    title: 'Base de Jurisprudência Interativa',
    estados: [
      'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 
      'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 
      'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
    ],
    estatisticas: estatisticas
  });
};

exports.filtrarJurisprudencia = (req, res) => {
  try {
    // Importar utilitário de jurisprudência
    const jurisprudenciaData = require('../utils/jurisprudenciaData');
    
    // Obter filtros da query
    const filtros = {
      estado: req.query.estado || '',
      quantidadePlantas: req.query.quantidadePlantas || '',
      tipoUso: req.query.tipoUso || '',
      resultado: req.query.resultado || ''
    };
    
    // Filtrar jurisprudências
    const resultados = jurisprudenciaData.filtrarJurisprudencias(filtros);
    
    // Retornar resultados
    res.json({ 
      success: true, 
      results: resultados,
      count: resultados.length
    });
  } catch (error) {
    console.error('Erro ao filtrar jurisprudência:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Ocorreu um erro ao filtrar a jurisprudência.' 
    });
  }
};

exports.getJurisprudenciaDetalhes = (req, res) => {
  try {
    const id = req.params.id;
    
    // Importar utilitário de jurisprudência
    const jurisprudenciaData = require('../utils/jurisprudenciaData');
    
    // Obter jurisprudência específica
    const jurisprudencia = jurisprudenciaData.getJurisprudenciaById(id);
    
    if (!jurisprudencia) {
      return res.status(404).render('404', { 
        title: 'Jurisprudência não encontrada',
        message: 'A jurisprudência solicitada não foi encontrada.'
      });
    }
    
    res.render('juridico/jurisprudencia-detalhes', { 
      title: 'Detalhes da Jurisprudência',
      jurisprudencia: jurisprudencia
    });
  } catch (error) {
    console.error('Erro ao obter detalhes da jurisprudência:', error);
    res.status(500).render('juridico/jurisprudencia', { 
      title: 'Base de Jurisprudência Interativa',
      estados: [
        'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 
        'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 
        'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
      ],
      error: 'Ocorreu um erro ao obter os detalhes da jurisprudência.'
    });
  }
};
